# Soumya Patlolla — Final Portfolio

## Ready
- Premium responsive UI
- Animated hero
- Project case-study modals
- Resume-backed profile
- Real LinkedIn / GitHub / email
- **Live public GitHub repository section** using GitHub's public repositories API
- Mobile-friendly
- Accessibility-friendly reduced motion

## Deploy to GitHub Pages
1. Create a repository named `portfolio` (or any public repo) under `patlolasoumya`.
2. Upload `index.html`.
3. In GitHub: Settings → Pages → Deploy from branch → `main` → `/root`.
4. GitHub will provide the live Pages URL.

The current ChatGPT connection does not expose a GitHub write/deploy action in this session, so I cannot safely push to your account without that connector being installed/authorized.
